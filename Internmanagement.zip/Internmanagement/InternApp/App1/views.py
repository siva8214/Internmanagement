import json
import io
import re
from django.contrib.auth.models import User, Group
from datetime import date, timedelta
import logging
from django.conf import settings
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.urls import reverse
from django.views.decorators.cache import cache_control
from App1.models import College, Course, Student, Studentattendance, Trainer, Internship, StudentInternship, Studentattendanceinternship, Degree, Department
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import  HttpResponseBadRequest, JsonResponse
from django.http import HttpResponse
from openpyxl import Workbook
from django.db.models import Q
from django.utils import timezone
from collections import defaultdict
from django.core.mail import EmailMessage
from twilio.rest import Client
import random


logger = logging.getLogger(__name__)


# Create your views here.
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            auth_login(request, user)
            return redirect('index')  
        else:
            messages.error(request, 'Invalid credentials')
            return redirect('login')
    else:
        return render(request, 'login.html')

def logout_view(request):
    auth_logout(request)
    return redirect('login')

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def add_user(request):
    user_groups = request.user.groups.all()
    u = request.user

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        password_confirm = request.POST['password_confirm']
        email = request.POST['email']
        first_name = request.POST.get('first_name', '')
        last_name = request.POST.get('last_name', '')
        group_id = request.POST.get('group', '')

        if password != password_confirm:
            messages.error(request, 'Passwords do not match.')
            return redirect('add_user')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
            return redirect('add_user')

        user = User.objects.create_user(username=username, password=password, email=email,
                                        first_name=first_name, last_name=last_name)

        if group_id:
            try:
                group = Group.objects.get(id=group_id)
                user.groups.add(group)
            except Group.DoesNotExist:
                messages.error(request, 'Selected group does not exist.')
                return redirect('add_user')

        messages.success(request, 'User created successfully.')
        return redirect('add_user')

    groups = Group.objects.all()
    context = {
        'groups': groups,
        'user_groups': user_groups,
        'u':u,
    }
    
    return render(request, 'add_user.html', context)

def extract_days(duration_str):
    """Extract days from a string like '2 days'."""
    match = re.match(r'(\d+)', duration_str)
    if match:
        return int(match.group(1))
    return None

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def index(request):
    user_groups = request.user.groups.all()
    u = request.user
    courses = Course.objects.all()
    course_data = []
    internships = Internship.objects.all()
    internship_data = []

    colleges_count = College.objects.count()
    courses_count = Course.objects.count()
    internship_count = Internship.objects.count()
    students_completed = Student.objects.filter(course_completed=True).count()
    students_ongoing = Student.objects.filter(course_completed=False, start_date__lte=date.today()).count()
    students_not_completed = Student.objects.filter(course_completed=False).count()
    total_students = Studentattendance.objects.values('intern_id').distinct().count()
    students_present_today = Studentattendance.objects.filter(date=date.today(), status='Present').count()

    # django_course_id = Course.objects.get(name="Django").id
    # students_in_django = Student.objects.filter(course_id=django_course_id).count()
    # completed_students = Student.objects.filter(course_id=django_course_id, course_completed=True).count()
    # uncompleted_students = students_in_django - completed_students

    # frontend_course_id = Course.objects.get(name="Frontend").id
    # students_in_frontend = Student.objects.filter(course_id=frontend_course_id).count()
    # completed_students_frontend = Student.objects.filter(course_id=frontend_course_id, course_completed=True).count()
    # uncompleted_students_frontend = students_in_frontend - completed_students_frontend

    # backend_course_id = Course.objects.get(name="Backend").id
    # students_in_backend = Student.objects.filter(course_id=backend_course_id).count()
    # completed_students_backend = Student.objects.filter(course_id=backend_course_id, course_completed=True).count()
    # uncompleted_students_backend = students_in_backend - completed_students_backend

    students_completed_internship = StudentInternship.objects.filter(internship_completed=True).count()
    students_not_completed_internship = StudentInternship.objects.filter(internship_completed=False).count()
    students_in_internships = StudentInternship.objects.filter(internship_completed=False, internship_start_date__lte=date.today()).count()
    for course in courses:
        students_in_course = Student.objects.filter(
            course=course,
            course_completed=False,
            start_date__lte=date.today()
        )
        
        total_days_left = 0
        count = 0
        total_days = []
        
        for student in students_in_course:
            try:
                if student.course_duration:
                    course_duration_str = student.course_duration.strip()
                    course_duration = extract_days(course_duration_str)
                    
                    if course_duration is not None and student.start_date:
                        end_date = student.start_date + timedelta(days=course_duration)
                        days_left = (end_date - date.today()).days
                        if days_left > 0:  # Only consider positive days left
                            total_days_left += days_left
                            count += 1

                        # Calculate the current day of the course
                        current_day = (date.today() - student.start_date).days + 1
                        total_days.append({
                            'current_day': current_day,
                            'days_left': days_left,
                        })
            except Exception:
                pass
        
        average_days_left = total_days_left / count if count > 0 else 0

        course_data.append({
            'name': course.name,
            'count': students_in_course.count(),
            'average_days_left': average_days_left,
            'total_days': total_days,  
        })
    
    for internship in internships:
        students_in_internship = StudentInternship.objects.filter(
            internship=internship,
            internship_completed=False,
            internship_start_date__lte=date.today()
        )
        
        total_days_left = 0
        count = 0
        total_days = []
        
        for student in students_in_internship:
            try:
                if student.duration and student.internship_start_date:
                    internship_duration_days = convert_duration_to_days(student.duration, student.duration_unit)
                    
                    if internship_duration_days > 0:
                        end_date = student.internship_start_date + timedelta(days=internship_duration_days)
                        days_left = (end_date - date.today()).days
                        if days_left > 0:
                            total_days_left += days_left
                            count += 1

                        current_day = (date.today() - student.internship_start_date).days + 1
                        total_days.append({
                            'current_day': current_day,
                            'days_left': days_left,
                        })
            except Exception:
                pass
        
        average_days_left = total_days_left / count if count > 0 else 0

        internship_data.append({
            'name': internship.name,
            'count': students_in_internship.count(),
            'average_days_left': average_days_left,
            'total_days': total_days,  
        })
    
    students_present_today_by_course = {}
    for course in courses:
        students_in_course = Student.objects.filter(
            course=course,
            course_completed=False,
            start_date__lte=date.today()
        )
        present_students_count = Studentattendance.objects.filter(
            intern_id__in=students_in_course.values_list('intern_id', flat=True),
            date=date.today(),
            status='Present'
        ).count()
        students_present_today_by_course[course.name] = present_students_count

    context = {
        'user_groups': user_groups,
        'u': u,
        'colleges_count': colleges_count,
        'courses_count': courses_count,
        'internship_count': internship_count,
        'students_completed':students_completed,
        'students_not_completed': students_not_completed,
        'students_ongoing': students_ongoing,
        'students_present_today': students_present_today,
        'total_students': total_students,
        # 'students_in_django': students_in_django,
        # 'completed_students': completed_students,
        # 'uncompleted_students': uncompleted_students,
        # 'students_in_frontend': students_in_frontend,
        # 'completed_students_frontend': completed_students_frontend,
        # 'uncompleted_students_frontend': uncompleted_students_frontend,
        # 'students_in_backend': students_in_backend,
        # 'completed_students_backend': completed_students_backend,
        # 'uncompleted_students_backend': uncompleted_students_backend,
        'students_completed_internship': students_completed_internship,
        'students_not_completed_internship':students_not_completed_internship,
        'students_in_internships':students_in_internships,
        'course_data': course_data,
        'internship_data': internship_data,
        
    }

    return render(request, 'index.html', context)

def convert_duration_to_days(duration, unit):
    if unit.lower() in ['day', 'days']:
        return duration
    elif unit.lower() in ['week', 'weeks']:
        return duration * 7
    elif unit.lower() in ['month', 'months']:
        return duration * 30
    else:
        return 0

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def college_and_course_form(request):
    college_messages = []
    course_messages = []
    trainer_messages = []
    internship_messages = []
    user_groups = request.user.groups.all()
    u=request.user

    if request.method == 'POST':
        if 'college_submit' in request.POST:
            college_name = request.POST.get('college_name')
            short_name = request.POST.get('short_name')
            if college_name and short_name:
                if not College.objects.filter(name=college_name).exists() and not College.objects.filter(short_name=short_name).exists():
                    College.objects.create(name=college_name, short_name=short_name)
                    college_messages.append('College added successfully!')
                else:
                    college_messages.append('A college with this name or short name already exists.')
            else:
                college_messages.append('Both fields are required for adding a college.')

        elif 'course_submit' in request.POST:
            course_name = request.POST.get('course_name')
            if course_name:
                if not Course.objects.filter(name=course_name).exists():
                    Course.objects.create(name=course_name)
                    course_messages.append('Course added successfully!')
                else:
                    course_messages.append('A course with this name already exists.')
            else:
                course_messages.append('Course name is required.')
        
        elif 'trainer_submit' in request.POST:
            trainer_name = request.POST.get('trainer_name')
            course_id = request.POST.get('course')
            if trainer_name and course_id:
                try:
                    course = Course.objects.get(id=course_id)
                    Trainer.objects.create(name=trainer_name, course=course)
                    trainer_messages.append('Trainer added successfully!')
                except Course.DoesNotExist:
                    trainer_messages.append('Selected course does not exist.')
            else:
                trainer_messages.append('Both fields are required for adding a trainer.')
    
        elif 'internship_submit' in request.POST: 
            internship_name = request.POST.get('internship_name')
            short_name = request.POST.get('short_name')
            if internship_name and short_name:
                if not Internship.objects.filter(name=internship_name).exists() and not Internship.objects.filter(short_name=short_name).exists():
                    Internship.objects.create(name=internship_name, short_name=short_name)
                    internship_messages.append('Internship added successfully!')
                else:
                    internship_messages.append('An internship with this name already exists.')
            else:
                internship_messages.append('Internship name is required.')

    colleges = College.objects.all()
    courses = Course.objects.all() 
    trainers = Trainer.objects.all()
    

    context = {
        'user_groups': user_groups,
        'u':u,
        'colleges': colleges,
        'courses': courses,
        'trainers': trainers,
        'college_messages': college_messages,
        'course_messages': course_messages,
        'trainer_messages': trainer_messages,
        'internship_messages': internship_messages,
    }

    return render(request, 'college_and_course_form.html', context)

def fetch_trainer_name(request):
    course_id = request.GET.get('course_id')
    try:
        trainer = Trainer.objects.get(course_id=course_id)
        trainer_name = trainer.name
    except Trainer.DoesNotExist:
        trainer_name = ''

    return JsonResponse({'trainer_name': trainer_name})

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def tables(request):
    user_groups = request.user.groups.all()
    u=request.user
   

    context = {
        'user_groups': user_groups,
        'u':u,
        
    }

    return render(request, 'tables.html', context)

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def collegetable(request, display_type='colleges'):
    user_groups = request.user.groups.all()
    u=request.user
    colleges = College.objects.all()
    courses = Course.objects.all() 
    trainers =Trainer.objects.all()
    internships =Internship.objects.all()

    context = {
        'user_groups': user_groups,
        'u':u,
        'colleges': colleges,
        'courses': courses,
        'trainers': trainers,
        'internships': internships
        
    }

    return render(request, 'collegetable.html', context)

def edit_college(request, college_id):
    if request.method == 'POST':
        new_college_name = request.POST.get('new_college_name')
        if new_college_name:
            college = get_object_or_404(College, pk=college_id)
            college.name = new_college_name
            college.save()
            return redirect('collegetable') 
        else:
            return HttpResponseBadRequest('Invalid data submitted.')
    else:
        return HttpResponseBadRequest('Invalid request method.')


def delete_college(request, college_id):
    if request.method == 'POST':
        college = get_object_or_404(College, pk=college_id)
        college.delete()
        return redirect('collegetable')  
    else:
        return HttpResponseBadRequest('Invalid request method.')

def edit_course(request, course_id):
    if request.method == 'POST':
        new_course_name = request.POST.get('new_course_name')
        if new_course_name:
            course = get_object_or_404(Course, pk=course_id)
            course.name = new_course_name
            course.save()
            return redirect('collegetable') 
        else:
            return HttpResponseBadRequest('Invalid data submitted.')
    else:
        return HttpResponseBadRequest('Invalid request method.')

def delete_course(request, course_id):
    if request.method == 'POST':
        course = get_object_or_404(Course, pk=course_id)
        course.delete()
        return redirect('collegetable') 
    else:
        return HttpResponseBadRequest('Invalid request method.')
    
def edit_trainer(request, trainer_id):
    trainer = get_object_or_404(Trainer, id=trainer_id)

    if request.method == 'POST':
        new_trainer_name = request.POST.get('new_trainer_name')
        new_assigned_course_id = request.POST.get('new_assigned_course')

        if new_trainer_name and new_assigned_course_id:
            trainer.name = new_trainer_name
            trainer.course = get_object_or_404(Course, id=new_assigned_course_id)
            trainer.save()
            messages.success(request, 'Trainer details updated successfully!')
        else:
            messages.error(request, 'Please provide valid inputs.')

        return redirect(reverse('collegetable'))  # Replace 'your_view_name' with the name of your main view

    return render(request, 'collegetable.html', {'trainer': trainer})

def delete_trainer(request, id):
    trainer = get_object_or_404(Trainer, id=id)
    trainer.delete()
    return redirect(reverse('collegetable'))

def edit_internship(request, id):
    if request.method == 'POST':
        new_internship_name = request.POST.get('new_internship_name')
        if new_internship_name:
            try:
                internship = Internship.objects.get(id=id)
                internship.name = new_internship_name
                internship.save()
                return redirect('collegetable')
            except Internship.DoesNotExist:
                pass
    return redirect('collegetable')

def delete_internship(request, id):
    if request.method == 'POST':
        try:
            internship = Internship.objects.get(id=id)
            internship.delete()
        except Internship.DoesNotExist:
            pass
    return redirect('collegetable')

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def add_new_student(request):
    user_groups = request.user.groups.all()
    u=request.user
   

    context = {
        'user_groups': user_groups,
        'u':u,
        
    }

    return render(request, 'add_new_student.html', context)

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def add_student(request):
    success_message = None
    error_message = None
    user_groups = request.user.groups.all()
    u = request.user

    if request.method == 'POST':
        try:
            name = request.POST['name']
            phone_number = request.POST['phone_number']
            whatsapp_number = request.POST.get('whatsapp')
            gender = request.POST['gender']
            aadhar_card_number = request.POST['aadhar_card_number']
            email = request.POST['email']

            if Student.objects.filter(aadhar_card_number=aadhar_card_number).exists():
                raise ValidationError("A student with this Aadhar card number already exists.")
            if Student.objects.filter(phone_number=phone_number).exists():
                raise ValidationError("A student with this phone number already exists.")
            if whatsapp_number and not whatsapp_number.isdigit():
                raise ValidationError("Invalid WhatsApp number. It should contain only digits.")

            college_id = request.POST['college']
            college = College.objects.get(id=college_id)
            state = request.POST['state']
            district = request.POST['district']
            passed_out_year = request.POST['passed_out_year']
            degree_name = request.POST['degree']
            department_name = request.POST.get('department')
            new_degree_name = request.POST.get('new_degree_name')
            new_department_name = request.POST.get('new_department_name')
            course_id = request.POST['course']
            course = Course.objects.get(id=course_id)
            course_duration = request.POST['course_duration']
            course_duration_unit = request.POST['course_duration_unit']
            course_mode = request.POST['course_mode']
            profile_photo = request.FILES.get('profile_photo')
            aadhar_card_file = request.FILES['aadhar_card_file']
            bonafide_certificate_file = request.FILES['bonafide_certificate_file']

            if aadhar_card_file.content_type != 'application/pdf':
                raise ValidationError("Aadhar Card file must be in PDF format")
            if bonafide_certificate_file.content_type != 'application/pdf':
                raise ValidationError("Bonafide Certificate file must be in PDF format")
            if profile_photo and profile_photo.content_type not in ['image/jpeg', 'image/png']:
                raise ValidationError("Profile photo must be in JPEG or PNG format")

            full_course_duration = f"{course_duration} {course_duration_unit}"

            trainer = Trainer.objects.filter(course=course).first()

            # Add new degree if needed
            if new_degree_name:
                degree_name = new_degree_name
                Degree.objects.create(name=degree_name)
            elif degree_name == 'add_new_degree':
                raise ValidationError("Please provide a new degree name.")

            # Handle new department
            if new_department_name:
                department_name = new_department_name
                Department.objects.create(name=department_name)
            elif department_name == 'add_new_department':
                raise ValidationError("Please provide a new department name.")

            student = Student(
                name=name,
                phone_number=phone_number,
                whatsapp_number=whatsapp_number,
                gender=gender,
                aadhar_card_number=aadhar_card_number,
                email=email,
                college=college,
                state=state,
                district=district,
                passed_out_year=passed_out_year,
                degree=degree_name,
                department=department_name,
                course=course,
                trainer=trainer,
                course_duration=full_course_duration,
                course_mode=course_mode,
                profile_photo=profile_photo,
                aadhar_card_file=aadhar_card_file,
                bonafide_certificate_file=bonafide_certificate_file
            )
            student.save()

            subject = 'Registration Successful'
            message = f'Dear {name},\n\nYou have successfully registered for the {course.name} course.\n\n\nThank You \nRegards, \nSivasubramani \nIntern-Pinespere Solutions'
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [email]

            email_message = EmailMessage(subject, message, from_email, recipient_list)
            email_message.send()

            # Send confirmation WhatsApp message
            whatsapp_message = f'Dear {name},\n\nYou have successfully registered for the {course.name} course.\n\n\nThank You \nRegards, \nSivasubramani \nIntern-Pinespere Solutions'
            # print(f"Phone number for WhatsApp message: {phone_number}")
            send_whatsapp_message(phone_number, whatsapp_message)


            success_message = "Student details added successfully!"
        except ValidationError as e:
            error_message = str(e)
        except Exception as e:
            error_message = "An error occurred while saving student details."

    degrees = Degree.objects.values_list('name', flat=True)
    departments = Department.objects.values_list('name', flat=True)
    colleges = College.objects.all()
    courses = Course.objects.all()

    context = {
        'user_groups': user_groups,
        'u': u,
        'degrees': degrees,
        'departments': departments,
        'colleges': colleges,
        'courses': courses,
        'success_message': success_message,
        'error_message': error_message
    }

    return render(request, 'add_student.html', context)


def check_aadhar(request):
    aadhar_card_number = request.GET.get('aadhar_card_number')
    try:
        student = Student.objects.get(aadhar_card_number=aadhar_card_number)
        data = {

            'exists': True,
            'name': student.name,
            'phone_number': student.phone_number,
            'email': student.email,
            'gender': student.gender,
            'college_id': student.college.id,
            'state': student.state,
            'district': student.district,
            'passed_out_year': student.passed_out_year,
            'degree': student.degree,
            'course_id': student.course.id,
            'trainer_name': student.trainer.name if student.trainer else '',
            'course_duration': student.course_duration.split()[0], 
            'course_duration_unit': student.course_duration.split()[1],
            'course_mode': student.course_mode,
            'profile_photo_name': student.profile_photo.name.split('/')[-1],
            'aadhar_card_file_name': student.aadhar_card_file.name.split('/')[-1],
            'bonafide_certificate_file_name': student.bonafide_certificate_file.name.split('/')[-1]   
        }
            
    except Student.DoesNotExist:
        data = {'exists': False}

    return JsonResponse(data)

otp = {}

def format_phone_number(phone_number):
    phone_number = phone_number.replace(' ', '') 
    if not phone_number.startswith('+91'):
        if (phone_number.startswith('0')):
            phone_number = '+91' + phone_number[1:]
        else:
            phone_number = '+91' + phone_number
    return phone_number

@csrf_exempt
def send_otp(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            phone_number = data.get('phone_number')
            phone_number = format_phone_number(phone_number)

            otp_code = random.randint(100000, 999999)
            request.session[phone_number] = otp_code

            client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
            client.messages.create(
                body=f'Your OTP code is {otp_code}',
                from_=settings.TWILIO_PHONE_NUMBER,
                to=phone_number
            )

            return JsonResponse({'message': 'OTP sent successfully!'}, status=200)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=400)

@csrf_exempt
def verify_otp(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            phone_number = data.get('phone_number')
            otp = data.get('otp')
            phone_number = format_phone_number(phone_number)

            if not phone_number or not otp:
                raise ValidationError("Phone number and OTP are required")

            stored_otp = request.session.get(phone_number)

            if str(stored_otp) == str(otp): 
                return JsonResponse({"success": True, "message": "OTP verified successfully"})
            else:
                raise ValidationError("Invalid OTP")

        except ValidationError as e:
            return JsonResponse({"success": False, "message": str(e)}, status=400)
        except Exception as e:
            return JsonResponse({"success": False, "message": "An error occurred"}, status=500)
    return JsonResponse({"success": False, "message": "Invalid request method"}, status=405)

def send_whatsapp_message(to, body):
    try:
        # print(f"Attempting to send WhatsApp message to {to} with body: {body}")
        if not to.startswith('+'):
            to = f'+91{to.lstrip("0")}'
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        message = client.messages.create(
            body=body,
            from_=settings.TWILIO_WHATSAPP_FROM,
            to=f'whatsapp:{to}'
        )
        print(f"WhatsApp message sent successfully: {message.sid}")
        return message.sid
    except Exception as e:
        print(f"Failed to send WhatsApp message: {e}")
        return None


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def add_student_internship(request):
    user_groups = request.user.groups.all()
    u = request.user

    degrees = Degree.objects.values_list('name', flat=True)
    departments = Department.objects.values_list('name', flat=True)
    colleges = College.objects.all()
    internships = Internship.objects.all()

    context = {
        'user_groups': user_groups,
        'u': u,
        'colleges': colleges,
        'internships': internships,
        'degrees': degrees,
        'departments': departments,
    }

    if request.method == 'POST':
        aadhar_card_number = request.POST.get('aadhar_card_number')
        name = request.POST.get('name')
        phone_number = request.POST.get('phone_number')
        whatsapp_number = request.POST.get('whatsapp')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        college_id = request.POST.get('college')
        state = request.POST.get('state')
        district = request.POST['district']
        passed_out_year = request.POST.get('passed_out_year')
        degree = request.POST.get('degree')
        department = request.POST.get('department')
        new_degree_name = request.POST.get('new_degree_name')
        new_department_name = request.POST.get('new_department_name')
        internship_id = request.POST.get('internship')
        duration = request.POST.get('internship_duration')
        duration_unit = request.POST.get('internship_duration_unit')
        mode = request.POST.get('internship_mode')
        profile_photo = request.FILES.get('profile_photo')
        aadhar_card_file = request.FILES.get('aadhar_card_file')
        bonafide_certificate_file = request.FILES.get('bonafide_certificate_file')

        if new_degree_name:
            degree_name = new_degree_name
            Degree.objects.create(name=degree_name)
        elif degree == 'add_new_degree':
            raise ValidationError("Please provide a new degree name.")
        else:
            degree_name = degree

            # Handle new department
        if new_department_name:
            department_name = new_department_name
            Department.objects.create(name=department_name)
        elif department == 'add_new_department':
            raise ValidationError("Please provide a new department name.")
        else:
            department_name = department

        college = College.objects.get(id=college_id)
        internship = Internship.objects.get(id=internship_id)

        try:
            student_internship = StudentInternship(
                aadhar_card_number=aadhar_card_number,
                name=name,
                phone_number=phone_number,
                whatsapp_number=whatsapp_number,
                email=email,
                gender=gender,
                college=college,
                state=state,
                district=district,
                passed_out_year=passed_out_year,
                degree=degree,
                department=department,
                internship=internship,
                duration=duration,
                duration_unit=duration_unit,
                mode=mode,
                profile_photo=profile_photo,
                aadhar_card_file=aadhar_card_file,
                bonafide_certificate_file=bonafide_certificate_file,
            )
            student_internship.save()

            subject = 'Registration Successful'
            message = f'Dear {name},\n\nYou have successfully registered for the {internship.name} course.\n\n\nThank You \nRegards, \nSivasubramani \nIntern-Pinespere Solutions'
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [email]

            email_message = EmailMessage(subject, message, from_email, recipient_list)
            email_message.send()

            # Send confirmation WhatsApp message
            whatsapp_message = f'Dear {name},\n\nYou have successfully registered for the {internship.name} course.\n\n\nThank You \nRegards, \nSivasubramani \nIntern-Pinespere Solutions'
            # print(f"Phone number for WhatsApp message: {phone_number}")
            send_whatsapp_message(phone_number, whatsapp_message)

            messages.success(request, 'Student internship details added successfully.')
            return redirect('add_student_internship')
        except Exception as e:
            messages.error(request, 'Error saving student internship details: ' + str(e))

    return render(request, 'add_student_internship.html', context)

@csrf_exempt
def check_aadhar_number(request):
    aadhar_card_number = request.GET.get('aadhar_card_number')
    try:
        internship = StudentInternship.objects.get(aadhar_card_number=aadhar_card_number)
        data = {
            'exists': True,
            'name': internship.name,
            'phone_number': internship.phone_number,
            'email': internship.email,
            'gender': internship.gender,
            'college_id': internship.college.id,
            'state': internship.state,
            'district': internship.district,
            'passed_out_year': internship.passed_out_year,
            'degree': internship.degree,
            'internship_id': internship.internship.id,
            'duration': internship.duration,
            'duration_unit': internship.duration,
            'mode': internship.mode,
            
        }
    except StudentInternship.DoesNotExist:
        data = {'exists': False}
    return JsonResponse(data)


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def studenttable(request):
    user_groups = request.user.groups.all()
    u = request.user

    query = request.GET.get('q', '').strip()
    course_completed = request.GET.get('course_completed')

    students = Student.objects.none()

    students = Student.objects.all()

    if query:
        search_terms = [term.strip() for term in query.split(',')]
        for term in search_terms:
            students = students.filter(
                Q(name__icontains=term) |
                Q(intern_id__icontains=term) |
                Q(whatsapp_number__icontains=term) |
                Q(phone_number__icontains=term) |
                Q(aadhar_card_number__icontains=term) |
                Q(degree__icontains=term) |
                Q(department__icontains=term) |
                Q(email__icontains=term) |
                Q(course_mode__icontains=term) |
                Q(course_duration__icontains=term) |
                Q(course__name__icontains=term)
            )

    if course_completed is not None:
        if course_completed.lower() == 'true':
            students = students.filter(course_completed=True)
        elif course_completed.lower() == 'false':
            students = students.filter(course_completed=False)

    context = {
        'students': students,
        'user_groups': user_groups,
        'u': u,
    }

    return render(request, 'studenttable.html', context)

def update_course_status(request):
    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        course_completed = request.POST.get('course_completed') == 'true'
        
        try:
            student = Student.objects.get(pk=student_id)
            student.course_completed = course_completed
            if course_completed:
                student.course_completed_date = timezone.now().date()
            else:
                student.course_completed_date = None
            student.save()
            
            return JsonResponse({
                'success': True,
                'completed_date': student.course_completed_date.strftime('%Y-%m-%d') if student.course_completed_date else None
            })
        except Student.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Student not found'})
    return JsonResponse({'success': False, 'error': 'Invalid request'})

def update_start_date(request):
    student_id = request.POST.get('student_id')
    is_started = request.POST.get('is_started') == 'true'  # Convert string to boolean

    try:
        student = Student.objects.get(pk=student_id)
        student.start_date = timezone.now().date() if is_started else None
        student.save()
        response_data = {
            'success': True,
            'start_date': student.start_date.strftime('%Y-%m-%d') if student.start_date else None
        }
    except Student.DoesNotExist:
        response_data = {'success': False}

    return JsonResponse(response_data)

def delete_student(request, pk):
    if request.method == 'POST':
        student = get_object_or_404(Student, pk=pk)
        student.delete()
        return redirect('studenttable') 
    else:
        return HttpResponseBadRequest('Invalid request method.')
    
def download_report(request):
    q = request.GET.get('q', '').strip()
    file_format = request.GET.get('format', 'xlsx')  # Default to 'xlsx' if format is not specified
    course_completed = request.GET.get('course_completed')  # Get course completion status filter

    # Filter students based on the search query and course completion status
    students = Student.objects.all()

    if q:
        search_terms = [term.strip() for term in q.split(',')]
        for term in search_terms:
            students = students.filter(
                Q(name__icontains=term) |
                Q(intern_id__icontains=term) |
                Q(whatsapp_number__icontains=term) |
                Q(phone_number__icontains=term) |
                Q(aadhar_card_number__icontains=term) |
                Q(degree__icontains=term) |
                Q(department__icontains=term) |
                Q(email__icontains=term) |
                Q(course_mode__icontains=term) |
                Q(course_duration__icontains=term) |
                Q(course__name__icontains=term)
            )

    if course_completed is not None:
        if course_completed.lower() == 'true':
            students = students.filter(course_completed=True)
        elif course_completed.lower() == 'false':
            students = students.filter(course_completed=False)

    # Determine the file name based on filters
    file_name = 'students_report.xlsx'
    if q:
        file_name = f'students_report_{q}.xlsx'
    if course_completed is not None:
        file_name = f'students_report_{course_completed}.xlsx'

    # Generate Excel report
    if file_format == 'xlsx':
        wb = Workbook()
        ws = wb.active
        ws.title = 'Filtered Students Report'

        headers = [
            'Intern ID',
            'Student Name',
            'Phone Number',
            'Aadhar Number',
            'Course',
            'Duration',
            'Course Mode',
            'Course Progress',
            'Completed Date',
        ]

        # Add headers to the first row
        for col_num, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_num, value=header)

        # Add student data starting from the second row
        for row_num, student in enumerate(students, 2):
            ws.cell(row=row_num, column=1, value=student.intern_id)
            ws.cell(row=row_num, column=2, value=student.name)
            ws.cell(row=row_num, column=3, value=student.phone_number)
            ws.cell(row=row_num, column=4, value=student.aadhar_card_number)
            ws.cell(row=row_num, column=5, value=student.course.name) 
            ws.cell(row=row_num, column=6, value=f"{student.course_duration}")
            ws.cell(row=row_num, column=7, value=student.course_mode)
            ws.cell(row=row_num, column=8, value='Completed' if student.course_completed else 'Not Completed')
            ws.cell(row=row_num, column=9, value=student.course_completed_date.strftime('%Y-%m-%d') if student.course_completed_date else '')

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'
        wb.save(response)
        return response

    # Handle invalid format
    return HttpResponse("Invalid format", status=400)

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def studenttable_internship(request):
    user_groups = request.user.groups.all()
    u = request.user

    query = request.GET.get('q', '').strip()
    course_completed = request.GET.get('course_completed')

    # Start with all internships
    internships = StudentInternship.objects.all()

    # Apply search term filters
    if query:
        search_terms = [term.strip() for term in query.split(',')]
        for term in search_terms:
            internships = internships.filter(
                Q(name__icontains=term) |
                Q(intern_id__icontains=term) |
                Q(whatsapp_number__icontains=term) |
                Q(phone_number__icontains=term) |
                Q(aadhar_card_number__icontains=term) |
                Q(degree__icontains=term) |
                Q(department__icontains=term) |
                Q(email__icontains=term) |
                Q(mode__icontains=term) |
                Q(duration__icontains=term) |
                Q(internship__name__icontains=term)
            )

    # Apply course completion status filter
    if course_completed:
        if course_completed.lower() == 'true':
            internships = internships.filter(internship_completed=True)
        elif course_completed.lower() == 'false':
            internships = internships.filter(internship_completed=False)

    context = {
        'user_groups': user_groups,
        'u': u,
        'internships': internships
    }

    return render(request, 'studenttable_internship.html', context)

def download_report_internship(request):
    q = request.GET.get('q', '').strip()
    file_format = request.GET.get('format', 'xlsx')  
    course_completed = request.GET.get('course_completed')  
    
    internships = StudentInternship.objects.all()

    if q:
        search_terms = [term.strip() for term in q.split(',')]
        for term in search_terms:
            internships = internships.filter(
                Q(name__icontains=term) |
                Q(intern_id__icontains=term) |
                Q(whatsapp_number__icontains=term) |
                Q(phone_number__icontains=term) |
                Q(aadhar_card_number__icontains=term) |
                Q(degree__icontains=term) |
                Q(department__icontains=term) |
                Q(email__icontains=term) |
                Q(mode__icontains=term) |
                Q(duration__icontains=term) |
                Q(internship__name__icontains=term)
            )

    if course_completed is not None:
        if course_completed.lower() == 'true':
            internships = internships.filter(internship_completed=True)
        elif course_completed.lower() == 'false':
            internships = internships.filter(internship_completed=False)
 
    # Determine the file name based on filters
    file_name = 'students_report.xlsx'

    # Generate Excel report
    if file_format == 'xlsx':
        wb = Workbook()
        ws = wb.active
        ws.title = 'Filtered Students Report'

        headers = [
            'Intern ID',
            'Student Name',
            'Phone Number',
            'Aadhar Number',
            'Internship',
            'Duration',
            'Course Mode',
            'Course Progress',
            'Completed Date',
        ]

        # Add headers to the first row
        for col_num, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_num, value=header)

        # Add student data starting from the second row
        for row_num, internships in enumerate(internships, 2):
            ws.cell(row=row_num, column=1, value=internships.intern_id)
            ws.cell(row=row_num, column=2, value=internships.name)
            ws.cell(row=row_num, column=3, value=internships.phone_number)
            ws.cell(row=row_num, column=4, value=internships.aadhar_card_number)
            ws.cell(row=row_num, column=5, value=internships.internship.name)  # Ensure this is correctly referencing the course name
            ws.cell(row=row_num, column=6, value=f"{internships.duration} {internships.duration_unit}")
            ws.cell(row=row_num, column=7, value=internships.mode)
            ws.cell(row=row_num, column=8, value='Completed' if internships.internship_completed else 'Not Completed')
            ws.cell(row=row_num, column=9, value=internships.internship_completed_date.strftime('%Y-%m-%d') if internships.internship_completed_date else '')

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'
        wb.save(response)
        return response

    # Handle invalid format
    return HttpResponse("Invalid format", status=400)

def delete_student_internship(request, pk):
    student_internship = get_object_or_404(StudentInternship, pk=pk)
    if request.method == 'POST':
        student_internship.delete()
        messages.success(request, 'Student internship details deleted successfully.')
        return redirect('studenttable_internship')
    return render(request, 'studenttable_internship.html')


@csrf_exempt
def update_internship_status(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        internship_id = data.get('internship_id')
        internship_completed = data.get('internship_completed')
        
        try:
            internship = StudentInternship.objects.get(pk=internship_id)
            internship.internship_completed = internship_completed
            if internship_completed:
                internship.internship_completed_date = timezone.now().date()
            else:
                internship.internship_completed_date = None
            internship.save()
            
            return JsonResponse({
                'success': True,
                'completed_date': internship.internship_completed_date.strftime('%Y-%m-%d') if internship.internship_completed_date else None
            })
        except StudentInternship.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Internship not found'})
    return JsonResponse({'success': False, 'error': 'Invalid request'})

@csrf_exempt
def update_internship_start_date(request):
    if request.method == 'POST':
        internship_id = request.POST.get('internship_id')
        is_started = request.POST.get('is_started') == 'true'

        try:
            internship = StudentInternship.objects.get(pk=internship_id)
            internship.internship_start_date = timezone.now().date() if is_started else None
            internship.save()
            response_data = {
                'success': True,
                'start_date': internship.internship_start_date.strftime('%Y-%m-%d') if internship.internship_start_date else None
            }
        except StudentInternship.DoesNotExist:
            response_data = {'success': False, 'error': 'StudentInternship not found'}

        return JsonResponse(response_data)
    return JsonResponse({'success': False, 'error': 'Invalid request'})

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def attendance(request):
    user_groups = request.user.groups.all()
    u = request.user


    context = {
        'user_groups': user_groups,
        'u': u,
    }

    return render(request, 'attendance.html', context)

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def student_attendance(request):
    user_groups = request.user.groups.all()
    u = request.user
    query = request.GET.get('q')
    selected_course = request.GET.get('course', '')
    courses = Studentattendance.objects.values_list('course_name', flat=True).distinct()
    students = Studentattendance.objects.values('intern_id', 'name', 'course_name','degree', 'department').distinct()
    # current_time = datetime.now().time()
    # current_date = date.today()
    # disable_editing = current_time >= datetime.strptime('11:30', '%H:%M').time()

    # if not request.user.is_superuser:
    #     if user_groups.filter(name='Frontendtrainer').exists():
    #         students = students.filter(course_name__iexact='Frontend')
    #     elif user_groups.filter(name='Djangotrainer').exists():
    #         students = students.filter(course_name__iexact='Django')
    #     elif user_groups.filter(name='Backendtrainer').exists():
    #         students = students.filter(course_name__iexact='Backend')


    if query:
        query_parts = query.split()
        for part in query_parts:
            students = students.filter(
                Q(name__icontains=part) | 
                Q(intern_id__icontains=part) | 
                Q(degree__icontains=part) | 
                Q(department__icontains=part) | 
                Q(course_name__icontains=part)
            )
    elif selected_course:
        students = students.filter(course_name=selected_course)

    if request.method == 'POST':
        if 'save_student' in request.POST:
            intern_id = request.POST.get('intern_id')
            name = request.POST.get('name')
            course_name = request.POST.get('course')
            degree = request.POST.get('degree')
            department = request.POST.get('department')
            if not intern_id or not name or not course_name or not degree or not department:
                messages.error(request, "Intern ID, Name, Course, and Department are required.")
            else:
                if not Studentattendance.objects.filter(intern_id=intern_id).exists():
                    Studentattendance.objects.create(intern_id=intern_id, name=name, course_name=course_name, degree=degree, department=department)
                    messages.success(request, f"Student {name} added successfully.")
                else:
                    messages.error(request, "A student with this Intern ID already exists.")
            return redirect('student_attendance')
        
        attendance_date = request.POST.get('attendance_date')
        # if attendance_date:
        #     attendance_date = datetime.strptime(attendance_date, '%Y-%m-%d').date()
        #     if attendance_date != current_date:
        #         messages.error(request, "You can only edit today's attendance.")
        #         return redirect('student_attendance')

        # if disable_editing:
        #     messages.error(request, "You are unable to edit the attendance after 11:30 AM")
        #     return redirect('student_attendance')
        
        if 'save_attendance' in request.POST:
            for student in students:
                intern_id = student['intern_id']
                attendance_key = f'attendance_{intern_id}'
                attendance_status = request.POST.get(attendance_key) == 'on'
                
                attendance_record, created = Studentattendance.objects.get_or_create(
                    intern_id=intern_id,
                    date=attendance_date,
                    defaults={'name': student['name'], 'course_name': student['course_name'], 'degree': student['degree'], 'department': student['department']}
                )
                attendance_record.attendance = attendance_status
                attendance_record.status = 'Present' if attendance_status else 'Absent'
                attendance_record.save()

            messages.success(request, f"Attendance for {attendance_date} saved successfully.")
            return redirect('student_attendance')

    fetch_date = request.POST.get('attendance_date')
    if fetch_date:
        students = Studentattendance.objects.filter(date=fetch_date).values('intern_id', 'name', 'attendance', 'course_name', 'degree', 'department')

    context = {
        'user_groups': user_groups,
        'u': u,
        'students': students,
        'query': query,
        'fetch_date': fetch_date,
        'courses': courses,
        # 'disable_editing': disable_editing,
    }

    return render(request, 'student_attendance.html', context)

def delete_student_attendance(request, intern_id):
    Studentattendance.objects.filter(intern_id=intern_id).delete()
    messages.success(request, "Student deleted successfully.")
    return redirect('student_attendance')

def delete_course_students(request):
    if request.method == 'POST':
        course_name = request.POST.get('course_name')
        if course_name:
            Studentattendance.objects.filter(course_name=course_name).delete()
            messages.success(request, f"All students under the course '{course_name}' have been deleted.")
        else:
            messages.error(request, "No course name provided.")
    return redirect('student_attendance')

def get_student_info(request):
    intern_id = request.GET.get('intern_id')
    if intern_id:
        try:
            student = Student.objects.get(intern_id=intern_id)
            course = Course.objects.get(student=student)
            return JsonResponse({'name': student.name, 'course': course.name, 'department': student.department, 'degree':student.degree})
        except Student.DoesNotExist:
            return JsonResponse({'error': 'Student not found'})
        except Course.DoesNotExist:
            return JsonResponse({'error': 'Course not found for this student'})
    return JsonResponse({'error': 'Invalid request'})



def fetch_attendance(request):
    fetch_date = request.GET.get('fetch_date')
    students = []

    if fetch_date:
        students = Studentattendance.objects.filter(date=fetch_date).values('intern_id', 'name', 'attendance')

    return render(request, 'student_attendance.html', {'students': students, 'fetch_date': fetch_date})


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def student_attendance_internship(request):
    user_groups = request.user.groups.all()
    u = request.user
    query = request.GET.get('q')
    selected_internship = request.GET.get('internship', '')
    internships = Studentattendanceinternship.objects.values_list('internship_name', flat=True).distinct()
    # Get fetch_date from POST if it exists, otherwise from GET
    fetch_date = request.POST.get('attendance_date') if request.method == 'POST' else request.GET.get('fetch_date')
    
    students = Studentattendanceinternship.objects.values('intern_id', 'name', 'internship_name', 'degree', 'department').distinct()

    if query:
        # Split the query into words and filter by each word
        query_parts = query.split()
        for part in query_parts:
            students = students.filter(
                Q(name__icontains=part) | 
                Q(intern_id__icontains=part) | 
                Q(degree__icontains=part) | 
                Q(department__icontains=part) 
            )
    elif selected_internship:
        students = students.filter(internship_name=selected_internship)

    else:
        students = Studentattendanceinternship.objects.all().values('intern_id', 'name', 'internship_name', 'degree', 'department').distinct()

    if request.method == 'POST':
        if 'save_student' in request.POST:
            intern_id = request.POST.get('intern_id')
            name = request.POST.get('name')
            internship_name = request.POST.get('internship')
            degree = request.POST.get('degree')
            department = request.POST.get('department')

            if not intern_id or not name or not internship_name or not degree or not department:
                messages.error(request, "Intern ID, Name, Internship, Degree, and Department are required.")
            else:
                if not Studentattendanceinternship.objects.filter(intern_id=intern_id).exists():
                    Studentattendanceinternship.objects.create(intern_id=intern_id, name=name, internship_name=internship_name, degree=degree, department=department)
                    messages.success(request, f"Student {name} saved successfully.")
                else:
                    messages.error(request, "A student with this Intern ID already exists.")
            return redirect('student_attendance_internship')

        if 'save_attendance' in request.POST and fetch_date:
            for student in students:
                intern_id = student['intern_id']
                attendance_key = f'attendance_{intern_id}'
                attendance_status = request.POST.get(attendance_key) == 'on'
                
                attendance_record, created = Studentattendanceinternship.objects.get_or_create(
                    intern_id=intern_id,
                    date=fetch_date,
                    defaults={
                        'name': student['name'], 
                        'internship_name': student['internship_name'],
                        'degree': student['degree'], 
                        'department': student['department']
                    }
                )
                attendance_record.attendance = attendance_status
                attendance_record.status = 'Present' if attendance_status else 'Absent'
                attendance_record.save()

            messages.success(request, f"Attendance saved successfully.")
            return redirect('student_attendance_internship')

        if fetch_date:
            students = Studentattendanceinternship.objects.filter(date=fetch_date).values('intern_id', 'name', 'attendance', 'internship_name','degree', 'department')

    context = {
        'user_groups': user_groups,
        'u': u,
        'students': students,
        'query': query,
        'fetch_date': fetch_date,
        'internships': internships,
    }

    return render(request, 'student_attendance_internship.html', context)

def get_student_info_internship(request):
    intern_id = request.GET.get('intern_id')
    if intern_id:
        try:
            studentinternship = StudentInternship.objects.get(intern_id=intern_id)
            internship = studentinternship.internship  
            return JsonResponse({'name': studentinternship.name, 'internship': internship.name,'degree':studentinternship.degree, 'department': studentinternship.department  })
        except StudentInternship.DoesNotExist:
            return JsonResponse({'error': 'Student not found'})
        except Internship.DoesNotExist:
            return JsonResponse({'error': 'Internship not found for this student'})
    return JsonResponse({'error': 'Invalid request'})

def delete_student_attendance_internship(request, intern_id):
    Studentattendanceinternship.objects.filter(intern_id=intern_id).delete()
    messages.success(request, "Student deleted succeessfully")
    return redirect('student_attendance_internship')

def delete_internship_students(request):
    if request.method == 'POST':
        internship_name = request.POST.get('internship_name')
        if internship_name:
            Studentattendanceinternship.objects.filter(internship_name=internship_name).delete()
            messages.success(request, f"All students under the internship '{internship_name}' have been deleted.")
        else:
            messages.error(request, "No internship name provided.")
    return redirect('student_attendance_internship')

def fetch_attendance_internship(request):
    fetch_date = request.GET.get('fetch_date')
    students = []

    if fetch_date:
        students = Studentattendanceinternship.objects.filter(date=fetch_date).values('intern_id', 'name', 'attendance')

    return render(request, 'student_attendance_internship.html', {'students': students, 'fetch_date': fetch_date})

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def student_attendance_report(request):
    user_groups = request.user.groups.all()
    u = request.user
    query = request.GET.get('q')
    date_filter = request.GET.get('date_filter')

    students = Studentattendance.objects.values('intern_id', 'name', 'course_name', 'degree', 'department').distinct()

    # if not request.user.is_superuser:
    #     if user_groups.filter(name='Frontendtrainer').exists():
    #         students = students.filter(course_name__iexact='Frontend')
    #     elif user_groups.filter(name='Djangotrainer').exists():
    #         students = students.filter(course_name__iexact='Django')
    #     elif user_groups.filter(name='Backendtrainer').exists():
    #         students = students.filter(course_name__iexact='Backend')

    if query:
        query_parts = query.split()
        for part in query_parts:
            students = students.filter(
                Q(name__icontains=part) | Q(intern_id__icontains=part) | Q(course_name__icontains=part) |
                Q(degree__icontains=part) | Q(department__icontains=part)
            )

    if date_filter:
        students = students.filter(date=date_filter)

    unique_dates = sorted(date for date in set(students.values_list('date', flat=True)) if date is not None)

    attendance_records = Studentattendance.objects.filter(intern_id__in=[student['intern_id'] for student in students])

    student_attendance_dict = defaultdict(lambda: {date: 'Absent' for date in unique_dates})
    for record in attendance_records:
        student_attendance_dict[record.intern_id][record.date] = record.status

    student_data = []
    for student in students:
        attendance_records = [
            student_attendance_dict[student['intern_id']].get(date, 'Absent')
            for date in unique_dates
        ]
        student_data.append({
            'intern_id': student['intern_id'],
            'name': student['name'],
            'course_name': student['course_name'],
            'degree': student['degree'],
            'department': student['department'],
            'attendance_records': attendance_records,
        })

    if request.method == 'POST':
        wb = Workbook()
        ws = wb.active
        ws.title = "Student Attendance Report"

        headers = ['S/N', 'Intern ID', 'Student Name', 'Course Name', 'Degree', 'Department'] + list(unique_dates)
        ws.append(headers)

        for idx, student in enumerate(student_data, start=1):
            row = [
                idx,
                student['intern_id'],
                student['name'],
                student['course_name'],
                student['degree'],
                student['department'],
            ] + ['✔' if status == 'Present' else '✖' for status in student['attendance_records']]
            ws.append(row)

        excel_buffer = io.BytesIO()
        wb.save(excel_buffer)
        excel_buffer.seek(0)

        subject = 'Attendance Report'
        if query:
            subject += f' -  {query}'
        if date_filter:
            subject += f' - Date: {date_filter}'
        body = 'Hi,\nGreetings of the Day !\nPlease find the attendance report'
        if query:
            body += f'\n Report for {query}'
        if date_filter:
            body += f'\nDate Filter: {date_filter}'
        from_email = 'smtp@gmail.com'
        to_email = 'pinesphereinternship@gmail.com'

        email = EmailMessage(subject, body, from_email, [to_email])
        email.attach('student_attendance_report.xlsx', excel_buffer.read(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

        try:
            email.send()
            messages.success(request, 'Email sent successfully.')
        except Exception as e:
            messages.error(request, f'Failed to send email: {str(e)}')

        return redirect('student_attendance_report')

    format = request.GET.get('format')
    if format == 'excel':
        wb = Workbook()
        ws = wb.active
        ws.title = "Student Attendance Report"

        headers = ['S/N', 'Intern ID', 'Student Name', 'Course Name', 'Degree', 'Department'] + list(unique_dates)
        ws.append(headers)

        for idx, student in enumerate(student_data, start=1):
            row = [
                idx,
                student['intern_id'],
                student['name'],
                student['course_name'],
                student['degree'],
                student['department'],
            ] + ['✔' if status == 'Present' else '✖' for status in student['attendance_records']]
            ws.append(row)

        response = HttpResponse(content_type='application/vnd.openpyxl.sheet')
        response['Content-Disposition'] = 'attachment; filename=student_attendance_report.xlsx'
        wb.save(response)
        return response

    context = {
        'user_groups': user_groups,
        'u': u,
        'students': student_data,
        'unique_dates': unique_dates,
        'query': query,
        'date_filter': date_filter,
    }

    return render(request, 'student_attendance_report.html', context)

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def student_attendance_report_internship(request):
    user_groups = request.user.groups.all()
    u = request.user
    query = request.GET.get('q')
    date_filter = request.GET.get('date_filter')
    students = Studentattendanceinternship.objects.all()

    if query:
        # Split the query into words and filter by each word
        query_parts = query.split()
        for part in query_parts:
            students = students.filter(
                Q(name__icontains=part) | 
                Q(intern_id__icontains=part) | 
                Q(degree__icontains=part) | 
                Q(department__icontains=part)
            )

    if date_filter:
        students = students.filter(date=date_filter)

    unique_dates = sorted(date for date in set(students.values_list('date', flat=True)) if date is not None)

    student_attendance = {}
    for student in students:
        if student.intern_id not in student_attendance:
            student_attendance[student.intern_id] = {
                'name': student.name,
                'internship_name': student.internship_name,
                'degree': student.degree,
                'department': student.department,
                'attendance_records': {date: 'Absent' for date in unique_dates}
            }
        student_attendance[student.intern_id]['attendance_records'][student.date] = student.status

    student_attendance_list = [
        {
            'intern_id': intern_id,
            'name': data['name'],
            'internship_name': data['internship_name'],
            'degree': data['degree'],
            'department': data['department'],
            'attendance_records': [data['attendance_records'][date] for date in unique_dates]
        }
    for intern_id, data in student_attendance.items()]

    if request.method == 'POST':
        wb = Workbook()
        ws = wb.active
        ws.title = "Student Attendance Report"

        headers = ['S/N', 'Intern ID', 'Student Name', 'Internship Name','degree', 'department'] + [date.strftime('%b %d') for date in unique_dates]
        ws.append(headers)

        for idx, student in enumerate(student_attendance_list, start=1):
            row = [
                idx,
                student['intern_id'],
                student['name'],
                student['internship_name'],
                student['degree'],
                student['department'],
            ] + ['✔' if status == 'Present' else '✖' for status in student['attendance_records']]
            ws.append(row)

        excel_buffer = io.BytesIO()
        wb.save(excel_buffer)
        excel_buffer.seek(0)

        subject = 'Attendance Report'
        if query:
            subject += f' -  {query}'
        if date_filter:
            subject += f' - Date: {date_filter}'
        body = 'Hi,\nGreetings of the Day !\nPlease find the attendance report'
        if query:
            body += f'\n Report for {query}'
        if date_filter:
            body += f'\nDate Filter: {date_filter}'
        from_email = 'smtp@gmail.com'
        to_email = 'pinesphereinternship@gmail.com'

        email = EmailMessage(subject, body, from_email, [to_email])
        email.attach('student_attendance_report.xlsx', excel_buffer.read(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

        try:
            email.send()
            messages.success(request, 'Email sent successfully.')
        except Exception as e:
            messages.error(request, f'Failed to send email: {str(e)}')

        return redirect('student_attendance_report_internship')

    format = request.GET.get('format')
    if format == 'excel':
        wb = Workbook()
        ws = wb.active
        ws.title = "Student Attendance Report"

        headers = ['S/N', 'Intern ID', 'Student Name', 'Internship Name','degree', 'department'] + [date.strftime('%b %d') for date in unique_dates]
        ws.append(headers)

        for idx, student in enumerate(student_attendance_list, start=1):
            row = [
                idx,
                student['intern_id'],
                student['name'],
                student['internship_name'],
                student['degree'],
                student['department'],
            ] + ['✔' if status == 'Present' else '✖' for status in student['attendance_records']]
            ws.append(row)

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=student_attendance_report.xlsx'
        wb.save(response)
        return response

    context = {
        'user_groups': user_groups,
        'u': u,
        'students': student_attendance_list,
        'unique_dates': unique_dates,
        'query': query,
        'date_filter': date_filter,
    }

    return render(request, 'student_attendance_report_internship.html', context)

# def send_daily_attendance_report():
#     today = date.today()
#     attendance_records = Studentattendance.objects.filter(date=today)
#     unique_dates = [today]

#     student_attendance_dict = defaultdict(lambda: {date: record.status for date in unique_dates})
#     for record in attendance_records:
#         student_attendance_dict[record.intern_id][record.date] = record.status

#     students = Studentattendance.objects.values('intern_id', 'name').distinct()
#     student_data = []
#     for student in students:
#         attendance_records = [
#             student_attendance_dict[student['intern_id']].get(date, 'Absent')
#             for date in unique_dates
#         ]
#         student_data.append({
#             'intern_id': student['intern_id'],
#             'name': student['name'],
#             'attendance_records': attendance_records,
#         })

#     wb = Workbook()
#     ws = wb.active
#     ws.title = "Student Attendance Report"

#     headers = ['S/N', 'Intern ID', 'Student Name', today]
#     ws.append(headers)

#     for idx, student in enumerate(student_data, start=1):
#         row = [
#             idx,
#             student['intern_id'],
#             student['name'],
#             '✔' if student['attendance_records'][0] == 'Present' else '✖'
#         ]
#         ws.append(row)

#     excel_buffer = io.BytesIO()
#     wb.save(excel_buffer)
#     excel_buffer.seek(0)

#     subject = 'Daily Attendance Report'
#     body = 'Please find the attached daily attendance report for {}.'.format(today)
#     from_email = 'smtp@gmail.com'
#     to_email = 'pinesphereinternship@gmail.com'

#     email = EmailMessage(subject, body, from_email, [to_email])
#     email.attach('student_attendance_report.xlsx', excel_buffer.read(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

#     try:
#         email.send()
#         print('Email sent successfully.')
#     except Exception as e:
#         print(f'Failed to send email: {str(e)}')

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required()
def qrscan(request):
    user_groups = request.user.groups.all()
    u = request.user
    if request.method == 'POST':
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)
        qr_code_data = body.get('qr_code_data')

        try:
            intern_id = qr_code_data.split("Intern ID: ")[1]

            # Check for Student
            try:
                student = Student.objects.get(intern_id=intern_id)
                response_data = {
                    'student_name': student.name,
                    'phone_number': student.phone_number,
                    'aadhar_card_number': student.aadhar_card_number,
                    'course': student.course.name,
                    'start_date': student.start_date,
                    'course_completed_date': student.course_completed_date,
                    'duration': student.course_duration,
                    'course_mode': student.course_mode,
                    'profile_photo_url': student.profile_photo.url if student.profile_photo else None,
                    'college_name': student.college.name,
                    'passed_out_year': student.passed_out_year,
                    'degree': student.degree,
                    'department':student.department,
                    'trainer_name': student.trainer.name
                }
            except Student.DoesNotExist:
                student_internship = StudentInternship.objects.get(intern_id=intern_id)
                response_data = {
                    'student_name': student_internship.name,
                    'phone_number': student_internship.phone_number,
                    'aadhar_card_number': student_internship.aadhar_card_number,
                    'college_name': student_internship.college.name,
                    'passed_out_year': student_internship.passed_out_year,
                    'degree': student_internship.degree,
                    'department': student_internship.department,
                    'internship': student_internship.internship.name,
                    'duration': student_internship.duration,
                    'duration_unit': student_internship.duration_unit,
                    'mode': student_internship.mode,
                    'profile_photo_url': student_internship.profile_photo.url if student_internship.profile_photo else None,
                    'internship_start_date': student_internship.internship_start_date,
                    'internship_completed_date': student_internship.internship_completed_date
                }

        except (Student.DoesNotExist, StudentInternship.DoesNotExist):
            response_data = {'error': 'Student not found'}
        
        return JsonResponse(response_data)

    context = {
        'csrf_token': request.META.get('CSRF_COOKIE'),
        'user_groups': user_groups,
        'user': u
    }
    
    return render(request, 'qrscan.html', context)

