from django.contrib import admin
from App1.models import College, Course, Student, Studentattendance, Trainer, Internship, StudentInternship, Studentattendanceinternship, Degree, Department

# Register your models here.
admin.site.register(College)
admin.site.register(Course)
admin.site.register(Student)
admin.site.register(Studentattendance)
admin.site.register(Trainer)
admin.site.register(Internship)
admin.site.register(StudentInternship)
admin.site.register(Studentattendanceinternship)
admin.site.register(Degree)
admin.site.register(Department)



