from django.db import models
import qrcode
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.utils import timezone
from django.core.files.base import ContentFile

# Create your models here.
class College(models.Model):
    name = models.CharField(max_length=100)
    short_name = models.CharField(max_length=10)

    def save(self, *args, **kwargs):
        self.short_name = self.short_name.upper()  
        super().save(*args, **kwargs)  
    
    def generate_short_name(self, name):
        words_to_skip = {'of', 'and', 'the'}
        words = name.split()
        short_name = ''.join([word[0].upper() for word in words if word.lower() not in words_to_skip])
        return short_name[:10]
    
    def __str__(self):
        return self.name
    
class Course(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name
    
class Trainer(models.Model):
    name = models.CharField(max_length=30)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

class Internship(models.Model):
    name = models.CharField(max_length=30)
    short_name = models.CharField(max_length=10)

    def save(self, *args, **kwargs):
        self.short_name = self.short_name.upper()  
        super().save(*args, **kwargs)  
    
    def __str__(self):
        return self.name

class Degree(models.Model):
    name = models.CharField(max_length=100)

class Department(models.Model):
    name = models.CharField(max_length=100)

class StudentInternship(models.Model):
    aadhar_card_number = models.CharField(max_length=12, unique=True)
    name = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=15)
    whatsapp_number = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(max_length=50)
    gender = models.CharField(max_length=10)
    college = models.ForeignKey(College, on_delete=models.CASCADE)
    state = models.CharField(max_length=30)
    district = models.CharField(max_length=30)
    passed_out_year = models.CharField(max_length=4)
    degree = models.CharField(max_length=10)
    department = models.CharField(max_length=100, blank=True, null=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE)
    duration = models.PositiveIntegerField()
    duration_unit = models.CharField(max_length=10)
    mode = models.CharField(max_length=10)
    profile_photo = models.ImageField(upload_to='profile_photos/')
    aadhar_card_file = models.FileField(upload_to='aadhar_files/')
    bonafide_certificate_file = models.FileField(upload_to='bonafide_files/')
    intern_id = models.CharField(max_length=50, unique=True, blank=True)
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True)
    internship_start_date = models.DateField(blank=True, null=True)
    internship_completed = models.BooleanField(default=False)
    internship_completed_date = models.DateField(blank=True, null=True)
    

    def save(self, *args, **kwargs):
        # Generate intern_id if not set
        if not self.intern_id:
            last_student = StudentInternship.objects.filter(internship=self.internship).order_by('id').last()
            if last_student:
                last_id = int(last_student.intern_id.split(self.internship.short_name)[1])
                new_id = last_id + 1
            else:
                new_id = 1
            self.intern_id = f"PS_{self.internship.short_name}{new_id:03d}"
        
        # Generate QR code if not set
        if not self.qr_code:
            qr_data = f"Intern ID: {self.intern_id}"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_data)
            qr.make(fit=True)
            qr_img = qr.make_image(fill='black', back_color='white')

            qr_image_io = BytesIO()
            qr_img.save(qr_image_io, format='PNG')
            qr_image_io.seek(0)

            self.qr_code.save(f"{self.intern_id}.png", ContentFile(qr_image_io.read()), save=False)
        
        if self.internship_completed and not self.internship_completed_date:
            self.internship_completed_date = timezone.now().date()
        elif not self.internship_completed:
            self.internship_completed_date = None

        if self.internship_start_date and not self.internship_start_date:
            self.internship_start_date = timezone.now().date()
        
        super().save(*args, **kwargs)
    
class Student(models.Model):
    name = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=15)
    whatsapp_number = models.CharField(max_length=15, blank=True, null=True)
    gender = models.CharField(max_length=10)
    aadhar_card_number = models.CharField(max_length=12)
    email = models.EmailField(max_length=50) 
    college = models.ForeignKey(College, on_delete=models.CASCADE)
    state = models.CharField(max_length=30)
    district = models.CharField(max_length=30)
    passed_out_year = models.CharField(max_length=4)
    degree = models.CharField(max_length=10)
    department = models.CharField(max_length=100, blank=True, null=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    trainer = models.ForeignKey(Trainer, on_delete=models.SET_NULL, null=True, blank=True)
    course_duration = models.CharField(max_length=20)
    course_mode = models.CharField(max_length=10)
    profile_photo = models.ImageField(upload_to='uploads/profile_photos/', blank=True, null=True)
    aadhar_card_file = models.FileField(upload_to='uploads/aadhar/')
    bonafide_certificate_file = models.FileField(upload_to='uploads/bonafide/')
    intern_id = models.CharField(max_length=20, unique=True, blank=True, null=True)
    qr_code = models.ImageField(upload_to='uploads/qr_codes/', blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    course_completed = models.BooleanField(default=False)
    course_completed_date = models.DateField(blank=True, null=True)


    def save(self, *args, **kwargs):
        if not self.intern_id:
            last_student = Student.objects.filter(college=self.college).order_by('id').last()
            if last_student:
                last_id = int(last_student.intern_id.split(self.college.short_name)[1])
                new_id = last_id + 1
            else:
                new_id = 1
            self.intern_id = f"PS_{self.college.short_name}{new_id:03d}"
        
        if not self.qr_code:
            qr_data = f"Intern ID: {self.intern_id}"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_data)
            qr.make(fit=True)
            qr_img = qr.make_image(fill_color="black", back_color="white")

            qr_image_io = BytesIO()
            qr_img.save(qr_image_io, format='PNG')
            qr_image_io.seek(0)

            self.qr_code = InMemoryUploadedFile(
                qr_image_io, None, f"{self.intern_id}.png", 'image/png', qr_image_io.tell(), None
            )
        
        if self.course_completed and not self.course_completed_date:
            self.course_completed_date = timezone.now().date()
        elif not self.course_completed:
            self.course_completed_date = None

        if self.start_date and not self.start_date:
            self.start_date = timezone.now().date()

        super().save(*args, **kwargs)
    

    def __str__(self):
        return self.name
    
class Studentattendance(models.Model):
    intern_id = models.CharField(max_length=100)
    name = models.CharField(max_length=30)
    course_name = models.CharField(max_length=50)
    degree = models.CharField(max_length=10)
    department = models.CharField(max_length=50)  
    attendance = models.BooleanField(default=False)
    status = models.CharField(max_length=10, default='Absent')
    date = models.DateField(null=True, blank=True)
   

    class Meta:
        unique_together = ('intern_id', 'date')
    
    def __str__(self):
        return self.name
    

class Studentattendanceinternship(models.Model):
    intern_id = models.CharField(max_length=100)
    name = models.CharField(max_length=30)
    internship_name = models.CharField(max_length=50)
    degree = models.CharField(max_length=10)
    department = models.CharField(max_length=50) 
    attendance = models.BooleanField(default=False)
    status = models.CharField(max_length=10, default='Absent')
    date = models.DateField(null=True, blank=True)
   

    class Meta:
        unique_together = ('intern_id', 'date')
    
    
    def __str__(self):
        return self.name
    
    

    



