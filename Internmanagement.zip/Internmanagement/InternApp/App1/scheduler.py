from apscheduler.schedulers.background import BackgroundScheduler
from django.core.mail import EmailMessage
from openpyxl import Workbook
import io
from .models import Studentattendance
from collections import defaultdict
from datetime import date


def send_daily_attendance_report():
    today = date.today()
    attendance_records = Studentattendance.objects.filter(date=today)
    unique_dates = [today]

    student_attendance_dict = defaultdict(lambda: {date: record.status for date in unique_dates})
    for record in attendance_records:
        student_attendance_dict[record.intern_id][record.date] = record.status

    students = Studentattendance.objects.values('intern_id', 'name').distinct()
    student_data = []
    for student in students:
        attendance_records = [
            student_attendance_dict[student['intern_id']].get(date, 'Absent')
            for date in unique_dates
        ]
        student_data.append({
            'intern_id': student['intern_id'],
            'name': student['name'],
            'attendance_records': attendance_records,
        })

    wb = Workbook()
    ws = wb.active
    ws.title = "Student Attendance Report"

    headers = ['S/N', 'Intern ID', 'Student Name', today]
    ws.append(headers)

    for idx, student in enumerate(student_data, start=1):
        row = [
            idx,
            student['intern_id'],
            student['name'],
            '✔' if student['attendance_records'][0] == 'Present' else '✖'
        ]
        ws.append(row)

    excel_buffer = io.BytesIO()
    wb.save(excel_buffer)
    excel_buffer.seek(0)

    subject = 'Daily Attendance Report'
    body = 'Please find the attached daily attendance report for {}.'.format(today)
    from_email = 'smtp@gmail.com'
    to_email = 'pinesphereinternship@gmail.com'

    email = EmailMessage(subject, body, from_email, [to_email])
    email.attach('student_attendance_report.xlsx', excel_buffer.read(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    try:
        email.send()
        print('Email sent successfully.')
    except Exception as e:
        print(f'Failed to send email: {str(e)}')

def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(send_daily_attendance_report, 'cron', hour=18, minute=0)
    scheduler.start()